# ADR-001: Identity authority and SSO strategy

**Status:** Proposed
**Date:** 2026-04-14
**Deciders:** _[to be filled]_
**Context area:** Cross-system authentication and identity management

> **Note:** This is a reconstructed version based on the working draft. Reconcile with your original copy before accepting. In particular, the phased implementation plan referenced in Consequences should be attached or linked.

## Context

The STI platform consists of three independent systems: STI Social (Open Social/Drupal), STI Portal / ATIO KB (Drupal), and SteveBot (custom TypeScript/Python chatbot). Currently there is no shared authentication — users have separate accounts on each system, and the only connection between Social and Portal is a hyperlink.

Users include staff from institutional partners (currently FAO and Welthungerhilfe), as well as independent researchers and practitioners who register directly. Institutional partners manage their own identity infrastructure (FAO uses Microsoft Entra ID; WHH has its own IdP).

Content on the STI Portal is gated by organisational affiliation — users from different organisations see different content. This access control currently has no formal connection to the identity system; it is configured per user by hand.

Without a shared identity layer, three problems compound:

- Users maintain multiple accounts across systems.
- Affiliation-based access cannot be reliably enforced at scale.
- New institutional partners require significant manual work to onboard.

## Decision

We will introduce **Keycloak as a centralised identity broker** for the STI platform.

- Keycloak becomes the single OIDC provider for all three systems (Social, Portal, SteveBot).
- STI Social remains the authority for user profiles, group memberships, and affiliation data.
- Institutional partners (FAO, WHH) are configured as federated identity providers in Keycloak via OIDC.
- Users without an institutional IdP create local accounts through Keycloak, with profile data stored in STI Social.
- An `affiliation` claim in the JWT, derived either from the federated IdP or from self-selection at registration, drives content access decisions.

## Consequences

**Easier:**

- Single sign-on across all three STI systems.
- Onboarding a new institutional partner becomes a matter of adding an IdP to Keycloak, not per-user account creation.
- Content access decisions can be made from the JWT, consistently across systems.

**Harder:**

- We now operate Keycloak as a piece of critical infrastructure. Someone must own it.
- Content access rules must migrate from per-user assignments to affiliation-based rules. Historical assignments need auditing.
- The organisation taxonomy must be synchronised between Portal (where it's authored) and Keycloak (where it's used for mapping). See a future ADR on taxonomy synchronisation.

**New work implied:**

- Install and operate Keycloak.
- Implement OIDC client integration in each of the three systems.
- Coordinate with FAO and WHH identity teams to register OIDC clients on their side.
- Migrate existing content-access assignments from per-user to affiliation-based.

## Alternatives considered

- **Direct OIDC between each system and each IdP.** Rejected: every new partner would require configuration in three places; SteveBot would need to reimplement auth every time.
- **Entra ID as the single broker.** Rejected: ties the platform to FAO's identity infrastructure, which would make onboarding non-FAO partners (WHH, researchers) awkward or impossible.
- **Do nothing; continue with separate accounts.** Rejected: fails on affiliation-based access control and scales badly as the user base grows.

## References

- Phased implementation plan: see working draft, 2026-04-14 (attach or link).

---

## Changelog

- 2026-04-14 — Proposed
