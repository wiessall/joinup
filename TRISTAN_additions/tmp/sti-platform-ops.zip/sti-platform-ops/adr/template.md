# ADR-NNN: [Short descriptive title]

**Status:** Proposed
**Date:** YYYY-MM-DD
**Deciders:** _[names or roles]_
**Context area:** _[identity | content model | infrastructure | governance | ...]_

## Context

Describe the situation, forces, and constraints that are driving a decision. What problem are we trying to solve? What have we already tried? What are the non-negotiables?

Keep this factual. Opinions go in Decision and Alternatives.

## Decision

State the decision in the active voice. "We will X." Keep it to one or two sentences if possible — the reasoning belongs in Consequences, the options in Alternatives.

## Consequences

What becomes easier as a result of this decision? What becomes harder? What new work does it imply? What risks does it introduce?

Be honest about the trade-offs. A decision with no downsides is usually not a decision.

## Alternatives considered

Briefly: what other options were on the table, and why weren't they chosen?

- **Alternative A** — short description. Why not: …
- **Alternative B** — short description. Why not: …

## Open questions

Anything unresolved that this ADR defers or depends on. If empty, delete this section.

## References

- Related ADRs, discussions, external documents.

---

## Changelog

- YYYY-MM-DD — Proposed by _[name]_
