# ADR-002: Innovation content model

**Status:** DRAFT — proposed, open for discussion
**Date:** 2026-04-16
**Deciders:** _[to be filled]_
**Context area:** Content model / data architecture

## Context

The platform's central entity is the "innovation" record. Different teams and stakeholders have proposed different sets of fields for this record — TRL level, climate relevance, gender impact, policy alignment, investment readiness, monitoring indicators, and more. Each request is individually reasonable; collectively they are unsustainable.

Three observations drive this ADR:

1. **The current content type grows without bound.** Every new team that arrives wants six to ten new fields, most of which other teams ignore. We are approaching the point where the edit form is unusable.
2. **Many requested "fields" are really evaluation frameworks.** TRL is a framework with five criteria on a scale. Climate relevance is another. Gender impact is another. Modelling each as a fixed field bakes one team's framework into the shared content type and makes it global.
3. **Cross-team reasoning is hard today.** "Innovations rated high by Team A on X *and* high by Team B on Y" cannot be expressed because the two scoring systems are not co-present in a queryable form.

The question this ADR addresses: **what are the properties of an innovation, and what is better modelled as something else (statement, relationship, framework instance)?**

This ADR depends on and informs:

- **ADR-003** (TBD): evaluation framework architecture — whether criteria become data.
- **ADR-004** (TBD): knowledge graph substrate — whether we stay in Drupal or move to a graph-shaped store.

## Decision

**Draft — not yet decided.** Proposing the following direction for discussion:

An innovation record has a **minimal core** of five to eight properties that every innovation has regardless of team. Candidates for the core:

- `id` — stable internal identifier
- `name` / `title`
- `short_description`
- `country` or `region` — controlled
- `domain` — broad thematic tag, AGROVOC-aligned
- `provenance` — who added it, when
- `canonical_url` — if sourced from an external system

Everything else is either:

- **A tagged classification** drawn from a controlled vocabulary (AGROVOC, schema.org, or a locally-stewarded taxonomy), or
- **A statement about** the innovation — authored by a team using a named evaluation framework, with its own scale, date, and evaluator.

Statements are first-class objects. A statement references an innovation, a framework, an evaluator, a timestamp, and a set of score values as defined by that framework. Multiple teams' statements about the same innovation co-exist; queries can combine them.

## Consequences

**Easier:**

- Teams can define new evaluation frameworks without adding fields to the shared content type.
- Cross-team queries ("high on X and Y") become queries over statements.
- The shared content type stabilises; editorial UX improves.
- External data sources can contribute statements without conforming to a single schema.

**Harder:**

- Requires a framework-authoring mechanism non-developers can use. This is non-trivial in Drupal; easier in a graph-shaped store. Which is why ADR-004 becomes pressing.
- Requires a steward for the core — someone empowered to say "no, that's not core, that's a framework."
- Existing fields need migration: per-field decisions on whether they stay as core, become a vocabulary, or become a framework.

**New work implied:**

- Decide the minimal core list (needs a workshop).
- Inventory existing fields and classify each.
- Define the statement/framework model (depends on ADR-003).
- Identify who owns the core definition (depends on governance / a future ADR).

## Alternatives considered

- **Continue the current approach.** Rejected: unsustainable, already producing friction and duplicated fields.
- **Add a "custom fields per content type" mechanism.** Rejected: solves the symptom (one content type is overloaded) by multiplying the problem (many content types are overloaded).
- **Model everything as key-value on a single flat entity.** Rejected: loses the structure we do need; makes typed queries impossible.

## Open questions

- What exactly belongs in the minimal core? (Needs workshop.)
- Does a statement reference an innovation by ID only, or also carry cached properties for display? (Performance vs consistency.)
- How are frameworks versioned when criteria change over time?
- Where do frameworks themselves live — in the KB, in a separate registry, or in the graph store?

## References

- [`policies/intake.md`](../policies/intake.md) — the "reframe as framework" triage outcome depends on this ADR being decided.
- [`diagrams/product-landscape.md`](../diagrams/product-landscape.md).

---

## Changelog

- 2026-04-16 — Drafted
