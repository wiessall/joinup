# STI platform ops

Governance, decisions, and cross-cutting documentation for the STI platform.

This repo is where non-code work lives: architectural decisions (ADRs), policies, the product inventory, and onboarding. Per-system code lives in the individual product repos.

## The STI platform, briefly

Four products, in different states of readiness. See [`diagrams/product-landscape.md`](diagrams/product-landscape.md) for the full picture and [`inventory/products.yaml`](inventory/products.yaml) for machine-readable detail.

- **ATIO KB** — Drupal portal, live. Knowledge base of agricultural innovations.
- **STI Social** — Open Social community, live. Hosts the Challenges group type.
- **SteveBot** — AI chatbot, planned.
- **Keycloak** — identity broker, planned infrastructure across all three.

## Where to file things

- **Bugs** — open an issue using the bug report template in the relevant product repo.
- **Feature requests** — open an issue in this repo using the feature request template. Read [`policies/intake.md`](policies/intake.md) first.
- **Architectural questions** — open a Discussion, or propose an ADR via PR. See [`policies/adr-process.md`](policies/adr-process.md).

## Index

| Path | What it is |
|---|---|
| `README.md` | You are here |
| `onboarding.md` | Start here if you just joined |
| `adr/` | Architecture decision records |
| `policies/` | Intake policy, ADR process |
| `diagrams/` | Current architecture visualisations |
| `inventory/` | Product metadata |
