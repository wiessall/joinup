# Onboarding: STI platform

If you just joined the team or project, start here.

## What the STI platform is

The STI (Science, Technology and Innovation) platform is a set of connected systems for cataloguing, discussing, and coordinating agricultural innovations. It currently consists of:

- **ATIO KB** (sti-portal.fao.org) — a Drupal-based knowledge base, live.
- **STI Social** — an Open Social community, live, hosting the Challenges group type for running innovation calls.
- **SteveBot** — a planned AI chatbot.
- **Keycloak** — planned identity infrastructure across all three systems.

Plus various workshop-level concepts that have been proposed but not scoped. See `diagrams/product-landscape.md` for the current picture.

## What this repo is

`sti-platform-ops` is the home for non-code work: decisions, policies, inventory, and onboarding. Per-system code lives in the individual product repos.

## How we work here

**Decisions are written down.** Architectural decisions become ADRs (`adr/`). Policies live in `policies/`. If you find yourself arguing the same point twice, write it down instead.

**Requests go through a triage.** Bugs and feature requests go to issue trackers, not meetings or chat. The intake policy (`policies/intake.md`) describes the four triage outcomes.

**The inventory is the source of truth for what products exist.** `inventory/products.yaml`. If a product isn't in there, it isn't real yet.

## Where to look first

| You want to… | Go to… |
|---|---|
| Report a bug | Product repo, bug template |
| Request a feature | This repo, feature request template. Read `policies/intake.md` first. |
| Ask an architectural question | Skim existing ADRs. If none answers your question, open a Discussion. |
| Understand the domain | Read `diagrams/product-landscape.md` and the ADRs in order. |
| Understand why something is the way it is | Look for an ADR. If there isn't one, the decision may not have been made deliberately. |

## Known unknowns

Several architectural questions are deliberately still open. Do not treat current implementation as a committed position on them:

- **ADR-002** (content model for innovations) — draft, under discussion.
- **ADR-003** (evaluation framework architecture) — not yet written.
- **ADR-004** (knowledge graph substrate) — not yet written; depends on ADR-002 and ADR-003.

## Who to ask

- Architecture / decisions: _[architecture owner]_
- Intake / triage: _[policy owner]_
- DevOps / deployment: _[ops contact]_
- Editorial / content: _[content lead]_

Update this list as team roles solidify.
