# How ADRs work at STI

Architectural decisions at STI are recorded as **ADRs (Architecture Decision Records)** — short markdown documents, one per decision, kept in this repo under `adr/`.

## Why

Decisions made in meetings and chat disappear. Decisions that disappear get re-made, inconsistently. An ADR captures what was decided, why, what alternatives were weighed, and what the consequences are — so the team (including future team members) can understand and amend decisions without starting from scratch.

## What counts as an ADR-level decision

A decision deserves an ADR if any of:

- It affects more than one system or team.
- It would be expensive to reverse.
- It establishes a pattern future work will follow.
- You've found yourself explaining "why we do it this way" more than once.

Things that don't need an ADR: bug fixes, per-ticket implementation choices, UI copy, short-term operational decisions.

## Lifecycle

Every ADR has a status:

- **Proposed** — drafted, under discussion, not yet acted on.
- **Accepted** — approved, in force.
- **Superseded by ADR-XXX** — replaced by a later decision; kept for historical reference.
- **Deprecated** — no longer in force, not superseded.

## Process

1. **Draft.** Copy `adr/template.md` to `adr/NNN-short-title.md`, where NNN is the next number. Fill in context, proposed decision, consequences, alternatives.
2. **PR.** Open a pull request adding the ADR in `Proposed` status. Tag the relevant deciders.
3. **Review.** Discussion happens in the PR. Revisions are commits to the PR. When discussion stabilises, deciders approve.
4. **Accept.** The ADR is merged with status changed to `Accepted`. Merge is the acceptance.
5. **Update.** If a decision is later revisited, open a new ADR that supersedes the old one. Do not edit the old ADR's content — only change its status to `Superseded by ADR-XXX`.

## Who decides

Each ADR names its `Deciders` — typically the architecture owner plus the sponsor (manager or equivalent) for significant cross-cutting decisions. Deciders are responsible for approving or rejecting, and for nominating reviewers.

An ADR can be proposed by anyone. Acceptance requires the named deciders.

## Numbering

Sequential, zero-padded to three digits: `001`, `002`, `003`. Numbers are assigned at draft time; if two drafts collide, the second reserves the next number.

Numbers are never reused. A withdrawn ADR keeps its number and gets status `Deprecated` with a note.

## Format

Follow [`template.md`](../adr/template.md). Keep it short — a good ADR is one to two pages, not ten. If it's getting long, move background material to a linked document and keep the ADR focused on the decision.

## Relationship to other processes

- **Feature requests** (see [`intake.md`](intake.md)) that trigger architectural questions are deferred to an ADR rather than refused. The intake policy's "defer to ADR" outcome is the main feeder for new ADRs.
- **Bug reports** do not become ADRs unless the fix itself requires a cross-cutting architectural decision.
